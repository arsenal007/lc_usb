










//do not change here!
#if defined (__AVR_ATmega48__)
#define VAR_88CHIP 1
#elif defined (__AVR_ATmega88__)
#define VAR_88CHIP 1
#elif defined (__AVR_ATmega168__)
#define VAR_8CHIP 1
#endif