
#include "config.h"
#include <avr/io.h>
#include <avr/interrupt.h>


uint16_t GetFrequencyRaw1(void);
uint8_t GetFrequencyRaw2(void);

void TimersInit(void);
