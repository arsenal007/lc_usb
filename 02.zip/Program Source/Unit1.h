//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>

#include "lc.h"

#include "hidlibrary.h"
#include "usbdata.h"
#include "other.h"

#include <Menus.hpp>
#include "Unit2.h"
#include "Unit3.h"
#include <Graphics.hpp>
#include <pngimage.hpp>
#include <Buttons.hpp>
#include <Dialogs.hpp>




//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TTimer *Timer1_listening;
	TButton *Button2;
	TButton *Button3;
	TBevel *Bevel1;
	TStatusBar *StatusBar1;
	TLabel *Mode;
	TLabel *Label5;
	TLabel *Display;
	TLabel *Prefix;
	TMainMenu *MainMenu1;
	TMenuItem *Settings1;
	TMenuItem *menu2;
	TLabel *Message;
	TButton *ButtonSet0;
	TTimer *Timer2;
	TMenuItem *menu3;
	TTimer *Timer3;
	TImage *Dot_green;
	TImage *Dot_red;
	TMenuItem *File1;
	TMenuItem *Exit1;
	void __fastcall Timer1_listeningTimer(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall Timer2Timer(TObject *Sender);
	void __fastcall ButtonSet0Click(TObject *Sender);
	void __fastcall menu2Click(TObject *Sender);
	void __fastcall menu3Click(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall Timer3Timer(TObject *Sender);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall Exit1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
