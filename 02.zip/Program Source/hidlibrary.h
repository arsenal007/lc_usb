

#include <windows.h>
#include <setupapi.h>
#include <string>
#include <vector>
#include <map>

#include <stdint.h>



typedef void (WINAPI* t_HidD_GetHidGuid)( OUT LPGUID );
typedef BOOLEAN (WINAPI* t_HidD_GetManufacturerString)(IN HANDLE, OUT PVOID, IN ULONG);
typedef BOOLEAN (WINAPI* t_HidD_GetProductString)(IN HANDLE, OUT PVOID, IN ULONG);
typedef BOOLEAN (WINAPI* t_HidD_GetFeature)(IN HANDLE, OUT PVOID, IN ULONG);
typedef BOOLEAN (WINAPI* t_HidD_SetFeature)(IN HANDLE, IN PVOID, IN ULONG);

typedef BOOLEAN (WINAPI* t_HidD_GetSerialNumberString)(IN HANDLE, IN PVOID, IN ULONG); //

using namespace std;


class HIDLibrary
{
protected:
	//!!!!!static const int datasize = sizeof(T);
	//!!!!!T data;
	//char pad[16];

	GUID m_hidguid;
	HINSTANCE hDLL;
	t_HidD_GetHidGuid HidD_GetHidGuid;
	t_HidD_GetManufacturerString HidD_GetManufacturerString;
	t_HidD_GetProductString HidD_GetProductString;
	t_HidD_GetSerialNumberString HidD_GetSerialNumberString;
	t_HidD_GetFeature HidD_GetFeature;
	t_HidD_SetFeature HidD_SetFeature;
	vector<string> m_HIDPaths;
	map<string,string> m_HIDDeviceIdents;
	string GetDevicePath(HDEVINFO hInfoSet, PSP_DEVICE_INTERFACE_DATA oInterface);
	string m_ConnectedDevice;
public:
	HIDLibrary();
	bool IsAvailableLib();
	int EnumerateHIDDevices();
	bool Connect(unsigned int device=0);
	string GetConnectedDevicePath();
	string GetConnectedDeviceName();
	int GetDeviceCount();
	string GetDeviceName(unsigned int i);
	int SendData(uint8_t ReportID, unsigned int datasize, uint8_t *data);
	int ReceiveData(uint8_t ReportID, unsigned int datasize, uint8_t *data);
	int IsConnectedDevice();

};

