"Mini USB L/C meter"
Software v2.1